package com.codealpha.rg_app;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    MainMechanism mainMecha;
    MainMechanism.Quote quote;
    TextView quoteText;
    TextView quoteAuthor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainMecha = new MainMechanism(getResources().openRawResource(R.raw.quotes));
        quoteText = (TextView) findViewById(R.id.text);
        quoteAuthor = (TextView) findViewById(R.id.author);

        quote = mainMecha.getRandomQuote();
        quoteText.setText(quote.getText());
        quoteAuthor.setText(quote.getAuthor());
    }

    public void getNewQuote(View view) {
        quote = mainMecha.getRandomQuote();
        quoteText.setText(quote.getText());
        quoteAuthor.setText(quote.getAuthor());
    }
}